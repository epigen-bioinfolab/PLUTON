---
Name: Hap.py
URL: https://github.com/Illumina/hap.py
Description: >
  Hap.py is a set of programs based on htslib to benchmark variant calls
  against gold standard truth datasets. Som.py output not currently supported.
---
