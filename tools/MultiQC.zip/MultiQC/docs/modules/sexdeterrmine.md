---
Name: Sex.DetErrMine
URL: https://github.com/TCLamnidis/Sex.DetERRmine
Description: >
  A python script to calculate the relative coverage of X and Y chromosomes, and their associated error bars, from the depth of coverage at specified SNPs.
---

A python script to calculate the relative coverage of X and Y chromosomes, and their associated error bars, from the depth of coverage at specified SNPs.
