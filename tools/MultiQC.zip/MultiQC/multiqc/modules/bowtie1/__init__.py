from __future__ import absolute_import

from .bowtie1 import MultiqcModule
