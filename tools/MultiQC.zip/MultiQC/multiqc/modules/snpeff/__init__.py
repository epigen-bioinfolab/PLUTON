from __future__ import absolute_import

from .snpeff import MultiqcModule
