from __future__ import absolute_import

from .picard import MultiqcModule
