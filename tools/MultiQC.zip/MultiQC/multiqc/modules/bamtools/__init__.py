from __future__ import absolute_import

from .bamtools import MultiqcModule
