from __future__ import absolute_import

from .kaiju import MultiqcModule
