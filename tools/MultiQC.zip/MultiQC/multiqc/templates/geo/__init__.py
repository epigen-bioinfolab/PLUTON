"""
=====
 Geo
=====

Welcome to Geo - an example template / easter egg.

Theme courtesy of the wonderful Geo for Bootstrap theme:
http://code.divshot.com/geo-bootstrap/

"""
import os

template_parent = "default"

template_dir = os.path.dirname(__file__)
base_fn = "base.html"

output_subdir = "multiqc_report"
copy_files = ["assets"]
